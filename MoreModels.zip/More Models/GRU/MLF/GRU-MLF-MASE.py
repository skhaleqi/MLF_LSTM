#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  7 15:23:33 2023

@author: grayman
"""

#%%
import numpy as np
import time
import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Lambda

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, GRU, Activation
# from keras.layers import CuDNNLSTM
from tensorflow.keras.optimizers import Nadam
import math
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

import random
import numpy
from tensorflow.compat.v1.random import set_random_seed

#%%
random.seed(1)
numpy.random.seed(1)
set_random_seed(2)

def mse(predictions, targets):
  return ((predictions - targets) ** 2).mean()

def rmse(actual, predicted):
    actual = np.array(actual)
    predicted = np.array(predicted)
    mse = np.mean((actual - predicted) ** 2)
    rmse_value = np.sqrt(mse)
    return rmse_value

def mae(actual, predicted):
    actual = np.array(actual)
    predicted = np.array(predicted)
    mae_value = np.mean(np.abs(actual - predicted))
    return mae_value

def r2_score(actual, predicted):
    actual = np.array(actual)
    predicted = np.array(predicted)
    mean_actual = np.mean(actual)
    ss_total = np.sum((actual - mean_actual) ** 2)
    ss_residual = np.sum((actual - predicted) ** 2)
    r2_value = 1 - (ss_residual / ss_total)    
    return r2_value

def mape(actual, predicted):
    epsilon = 1e-6  # جلوگیری از تقسیم بر صفر
    actual = np.array(actual)
    predicted = np.array(predicted)
    mape_value = np.mean(np.abs((actual - predicted) / (actual + epsilon))) * 100
    return mape_value

# محاسبه MASE
def mase(actual, predicted, train_data):
    epsilon = 1e-6  # جلوگیری از تقسیم بر صفر
    actual = np.array(actual)
    predicted = np.array(predicted)
    train_data = np.array(train_data)

    # محاسبه پیش‌بینی Naive
    naive_forecast = np.roll(train_data, 1)[1:]  # شیفت به سمت راست برای پیش‌بینی Naive
    mae_naive = mae(train_data[1:], naive_forecast)
    mae_value = mae(actual, predicted)
    mase_value = mae_value / (mae_naive + epsilon)
    return mase_value

def smape(actual, predicted):
    actual = np.array(actual)
    predicted = np.array(predicted)
    return 100 * np.mean(2 * np.abs(actual - predicted) / (np.abs(actual) + np.abs(predicted)))
    
def readDataset(filename):
    text_file = open(filename, 'r')
    dataset = []   
    for line in text_file:  
        line = line.split(',')      
        dt = [ float(x) for x in line ]
        dataset.append(dt)    
    text_file.close()
    dataset = np.array(dataset)
    return dataset

def tagData(data, perc):
    sz = math.ceil(data.shape[0]*perc/100)
    dat = np.zeros((data.shape[0], data.shape[1]*2))
    dat[:data.shape[0], :data.shape[1]] =data  #append column for labels
    dat[:data.shape[0]-1, data.shape[1]:] =data[1:,:]  #append column for labels   
    
    xtrain = dat[:sz, :8]
    ytrain = dat[:sz, 8:]
    
    xtest = dat[sz-1:, :8]
    ytest = dat[sz-1:, 8:]
    
    xtrain = xtrain.reshape((xtrain.shape[0], 1, xtrain.shape[1]))
    xtest = xtest.reshape((xtest.shape[0], 1, xtest.shape[1]))
    
    return xtrain, ytrain, xtest, ytest



#%%

data = pd.read_csv('/Users/grayman/Documents/PhD/Data/EurUsd-ziroout.csv',sep=',',index_col='Date',parse_dates=True)
#print(data.head())

new_data = data.iloc[:,[0,1,2,3,4,5,6,7]]
new_data = np.array(new_data)
#print(new_data.head())

#print(data.shape);


percentage = 60

xtrain, ytrain,xtest,ytest = tagData(new_data,percentage)
print('training samples: ', xtrain.shape)
print('testing samples: ', xtest.shape)
print('training pred: ', ytrain.shape)
print('testing pred: ', ytest.shape)
#%%

activations=['tanh','relu','sigmoid']
history_dictionary = {}
opt = Nadam(lr=0.00001, beta_1=0.09, beta_2=0.0999, epsilon=None, schedule_decay=0.0004)
predictions = {}

#%%
@tf.function
def MLF(yTrue, yPred):
     sig = 0.1
     lam = 0.9
     v   = Lambda(lambda x: x*lam)((yTrue-yPred))
     vn  = Lambda(lambda x: x*sig)(K.abs((yTrue[:,1]+yTrue[:,2]+yTrue[:,5]+yTrue[:,6])/4 - (yPred[:,1]+yPred[:,2]+yPred[:,5]+yPred[:,6])/4))
     vn1 = Lambda(lambda x: x*sig)(K.abs((yTrue[:,0]+yTrue[:,3]+yTrue[:,4]+yTrue[:,7])/4 - (yPred[:,0]+yPred[:,3]+yPred[:,4]+yPred[:,7])/4))
     #too bad
     #vn  = Lambda(lambda x: x*lam)(K.abs((yTrue[:,5]+yTrue[:,6])/2 - (yPred[:,5]+yPred[:,6])/2))
     #vn1 = Lambda(lambda x: x*lam)(K.abs((yTrue[:,4]+yTrue[:,7])/2 - (yPred[:,4]+yPred[:,7])/2))
     v1  = K.square((v[:,0]-vn1))
     v2  = K.square((v[:,1]-vn))
     v3  = K.square((v[:,2]-vn))
     v4  = K.square((v[:,3]-vn1))
     v1a = K.square((v[:,4]-vn1))
     v2a = K.square((v[:,5]-vn))
     v3a = K.square((v[:,6]-vn))
     v4a = K.square((v[:,7]-vn1))
     vm  = K.concatenate([v1, v2, v3, v4,v1a,v2a,v3a,v4a])
     vmx = K.mean(vm)
     return vmx



#%%

units=200
epochs = 150
verbose=0

for i, act in enumerate(activations):
    start =  time.time()
    cand = Sequential()
    cand.add(GRU(units, activation=act, input_shape=(xtrain.shape[1], xtrain.shape[2])))
    cand.add(Dense(8))
    cand.compile(loss=MLF, optimizer=opt)
    cand_history = cand.fit(xtrain, ytrain, epochs=epochs, batch_size=72, validation_data=(xtest, ytest), verbose=verbose, shuffle=False)
    history_dictionary[act] = (cand_history, cand)
    print("done training model with activation", act, "  ", i+1,"/", len(activations), "completed.")
    end =  time.time()
    print("time of execution = ", end-start, "seconds")

   
#%% MASE

def evaluate(xtest, name="Open",filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High":1, "Low":2, "Close":3}
    groups = {"Open": [], "High":[], "Low": [], "Close": []}
    
    with open(filename,"w") as f:
        for label, pair in history_dictionary.items():
            model =pair[1]
            prediCand = model.predict(xtest)
            df_save = pd.DataFrame({
                "y_true_Open": ytest[:, 0],
                "y_pred_Open": prediCand[:, 0],
                "y_true_High": ytest[:, 1],
                "y_pred_High": prediCand[:, 1],
                "y_true_Low": ytest[:, 2],
                "y_pred_Low": prediCand[:, 2],
                "y_true_Close": ytest[:, 3],
                "y_pred_Close": prediCand[:, 3]
            })
            df_save.to_csv(f"Results_{label}.csv", index=False)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:,id_]
                act = ytest[:,id_]
                mean_sq_err = mase(act, pred, ytrain[:, id_])
                output = f"{label},{name}(MASE),{mean_sq_err}\n"
                print(label, ": ", name, " MASE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

#%%

dictionary  = evaluate(xtest,"Open","GRU_MLF_MASE_result_1.txt")
print(history_dictionary.items())
#%%
def plot_validation_loss(filename="validation_loss.png"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('Candle validation loss(MASE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename)    
    plt.show()

#%%
plot_validation_loss("GRU_MLF_MASE_validation_loss.png")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./GRU_MLF_MASE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.png'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('GRU MLF MASE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename)
        plt.show()
        
plot_error(dictionary,3,'GRU_MLF_MASE_my_error_plot.png')


def plot( name="Open", filename="plot.png"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename)
        plt.show()

plot("Open","GRU_MLF_Open_MASE.png")
plot("High","GRU_MLF_High_MASE.png")
plot("Low","GRU_MLF_Low_MASE.png")
plot("Close","GRU_MLF_Close_MASE.png")
#%% MSE

def evaluate(xtest, name="Open",filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High":1, "Low":2, "Close":3}
    groups = {"Open": [], "High":[], "Low": [], "Close": []}
    
    with open(filename,"w") as f:
        for label, pair in history_dictionary.items():
            model =pair[1]
            prediCand = model.predict(xtest)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:,id_]
                act = ytest[:,id_]
                mean_sq_err = mse(act, pred)
                output = f"{label},{name}(MSE),{mean_sq_err}\n"
                print(label, ": ", name, " MSE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

dictionary  = evaluate(xtest,"Open","GRU_MLF_MSE_result_1.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.png"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('Candle validation loss(MSE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename)    
    plt.show()

plot_validation_loss("GRU_MLF_MSE_validation_loss.png")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./GRU_MLF_MSE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.png'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('GRU MLF MSE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename)
        plt.show()
        
plot_error(dictionary,3,'GRU_MLF_MSE_my_error_plot.png')


def plot( name="Open", filename="plot.png"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename)
        plt.show()

plot("Open","GRU_MLF_Open_MSE.png")
plot("High","GRU_MLF_High_MSE.png")
plot("Low","GRU_MLF_Low_MSE.png")
plot("Close","GRU_MLF_Close_MSE.png")

#%% RMSE

def evaluate(xtest, name="Open",filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High":1, "Low":2, "Close":3}
    groups = {"Open": [], "High":[], "Low": [], "Close": []}
    
    with open(filename,"w") as f:
        for label, pair in history_dictionary.items():
            model =pair[1]
            prediCand = model.predict(xtest)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:,id_]
                act = ytest[:,id_]
                mean_sq_err = rmse(act, pred)
                output = f"{label},{name}(RMSE),{mean_sq_err}\n"
                print(label, ": ", name, " RMSE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

dictionary  = evaluate(xtest,"Open","GRU_MLF_RMSE_result_1.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.png"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('MLF Candle validation loss(RMSE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename)    
    plt.show()

plot_validation_loss("GRU_MLF_RMSE_validation_loss.png")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./GRU_MLF_RMSE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.png'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('GRU MLF RMSE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename)
        plt.show()
        
plot_error(dictionary,3,'GRU_MLF_RMSE_my_error_plot.png')


def plot( name="Open", filename="plot.png"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename)
        plt.show()

plot("Open","GRU_MLF_Open_RMSE.png")
plot("High","GRU_MLF_High_RMSE.png")
plot("Low","GRU_MLF_Low_RMSE.png")
plot("Close","GRU_MLF_Close_RMSE.png")

#%% MAE

def evaluate(xtest, name="Open",filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High":1, "Low":2, "Close":3}
    groups = {"Open": [], "High":[], "Low": [], "Close": []}
    
    with open(filename,"w") as f:
        for label, pair in history_dictionary.items():
            model =pair[1]
            prediCand = model.predict(xtest)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:,id_]
                act = ytest[:,id_]
                mean_sq_err = mae(act, pred)
                output = f"{label},{name}(MAE),{mean_sq_err}\n"
                print(label, ": ", name, " MAE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

dictionary  = evaluate(xtest,"Open","GRU_MAE_result_1.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.png"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('Candle validation loss(MAE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename)    
    plt.show()

plot_validation_loss("GRU_MAE_validation_loss.png")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./GRU_MLF_MAE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.png'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('GRU MLF MAE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename)
        plt.show()
        
plot_error(dictionary,3,'GRU_MLF_MAE_my_error_plot.png')


def plot( name="Open", filename="plot.png"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename)
        plt.show()

plot("Open","GRU_MLF_Open_MAE.png")
plot("High","GRU_MLF_High_MAE.png")
plot("Low","GRU_MLF_Low_MAE.png")
plot("Close","GRU_MLF_Close_MAE.png")

