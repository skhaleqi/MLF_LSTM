#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov  5 12:22:18 2025

@author: grayman
"""

import os
import pandas as pd
import numpy as np
from scipy import stats

# -------------------------------
# تنظیمات اولیه
# -------------------------------
# مسیر پوشه‌ای که فایل‌ها داخلش هستند
folder = "."

# اکتیوشن‌هایی که می‌خوای بررسی کنی
activations = ["relu", "tanh", "sigmoid"]

# مدل‌هایی که داری (مثل GRU یا BiLSTM)
models = ["GRU", "BiLSTM","MLP","RNN"]

# -------------------------------
# تابع آزمون Diebold–Mariano
# -------------------------------
def diebold_mariano(y_true, y_pred1, y_pred2):
    """
    Safe implementation of Diebold–Mariano test
    Handles unequal array lengths by trimming to min length.
    """
    min_len = min(len(y_true), len(y_pred1), len(y_pred2))
    y_true = y_true[:min_len]
    y_pred1 = y_pred1[:min_len]
    y_pred2 = y_pred2[:min_len]

    e1 = (y_true - y_pred1) ** 2
    e2 = (y_true - y_pred2) ** 2
    d = e1 - e2
    mean_d = np.mean(d)
    var_d = np.var(d, ddof=1)
    dm_stat = mean_d / np.sqrt(var_d / len(d))
    p_value = 2 * (1 - stats.t.cdf(abs(dm_stat), df=len(d) - 1))
    return dm_stat, p_value
# -------------------------------
# تابع اجرای تست‌ها برای همه فایل‌ها
# -------------------------------
results = []

for model in models:
    for act in activations:
        flf_file = os.path.join(folder, f"Results_{model}_FLF_{act}.csv")
        mlf_file = os.path.join(folder, f"Results_{model}_MLF_{act}.csv")

        if os.path.exists(flf_file) and os.path.exists(mlf_file):
            print(f"\nRunning DM test for {model} - {act}...")

            df_flf = pd.read_csv(flf_file)
            df_mlf = pd.read_csv(mlf_file)

            # فرض بر اینه که ستون‌ها y_true_Close و y_pred_Close وجود دارن
            y_true = df_flf["y_true_Close"].values
            y_pred_flf = df_flf["y_pred_Close"].values
            y_pred_mlf = df_mlf["y_pred_Close"].values

            dm_stat, p_val = diebold_mariano(y_true, y_pred_flf, y_pred_mlf)
            sig = "Significant" if p_val < 0.05 else "Not Significant"

            results.append([model, act, dm_stat, p_val, sig])
        else:
            print(f"⚠️ File missing for {model} - {act}")

# -------------------------------
# ذخیره خروجی
# -------------------------------
df_results = pd.DataFrame(results, columns=["Model", "Activation", "DM Statistic", "p-Value", "Significance"])

# ذخیره به فایل متنی و CSV
df_results.to_csv("DM_Results_All.csv", index=False)

with open("DM_Results_All.txt", "w") as f:
    f.write("Diebold–Mariano Test Results (FLF vs MLF)\n\n")
    for _, row in df_results.iterrows():
        f.write(f"{row['Model']} ({row['Activation']}): DM={row['DM Statistic']:.4f}, p={row['p-Value']:.6f}, {row['Significance']}\n")

print("\n✅ All tests completed successfully!")
print(df_results)