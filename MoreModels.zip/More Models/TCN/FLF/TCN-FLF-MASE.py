#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TCN version of your FLF code (sequence input)
"""

#%%
import numpy as np
import time
import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Lambda

# ✨ تغییر: استفاده از Model و لایه‌های TCN
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Dropout, Activation, Conv1D, GlobalAveragePooling1D, Add, Input

from tensorflow.keras.optimizers import Nadam
import math
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

import random
import numpy
from tensorflow.compat.v1.random import set_random_seed

#%%
random.seed(1)
numpy.random.seed(1)
set_random_seed(2)

def mse(predictions, targets):
    return ((predictions - targets) ** 2).mean()

def rmse(actual, predicted):
    actual = np.array(actual); predicted = np.array(predicted)
    return np.sqrt(np.mean((actual - predicted) ** 2))

def mae(actual, predicted):
    actual = np.array(actual); predicted = np.array(predicted)
    return np.mean(np.abs(actual - predicted))

def r2_score(actual, predicted):
    actual = np.array(actual); predicted = np.array(predicted)
    mean_actual = np.mean(actual)
    ss_total = np.sum((actual - mean_actual) ** 2)
    ss_residual = np.sum((actual - predicted) ** 2)
    return 1 - (ss_residual / ss_total)

def mape(actual, predicted):
    epsilon = 1e-6
    actual = np.array(actual); predicted = np.array(predicted)
    return np.mean(np.abs((actual - predicted) / (actual + epsilon))) * 100

# محاسبه MASE
def mase(actual, predicted, train_data):
    epsilon = 1e-6
    actual = np.array(actual); predicted = np.array(predicted); train_data = np.array(train_data)
    naive_forecast = np.roll(train_data, 1)[1:]
    mae_naive = mae(train_data[1:], naive_forecast)
    return mae(actual, predicted) / (mae_naive + epsilon)

def smape(actual, predicted):
    actual = np.array(actual); predicted = np.array(predicted)
    return 100 * np.mean(2 * np.abs(actual - predicted) / (np.abs(actual) + np.abs(predicted)))

def readDataset(filename):
    text_file = open(filename, 'r')
    dataset = []
    for line in text_file:
        line = line.split(',')
        dt = [float(x) for x in line]
        dataset.append(dt)
    text_file.close()
    return np.array(dataset)

# ✨ تغییر مهم: ساخت توالی با طول seq_len برای TCN
def tagData(data, perc, seq_len=32, n_out=4):
    """
    data: np.array (T, F)  → F=4 برای FLF (OHLC)
    seq_len: طول توالی ورودی برای TCN (مثل 32)
    n_out: خروجی‌های پیش‌بینی (FLF=4)
    """
    T, F = data.shape
    X, Y = [], []
    for t in range(seq_len, T-1):
        X.append(data[t-seq_len:t, :F])  # ورودی: seq_len×F
        Y.append(data[t+1, :n_out])      # خروجی: OHLC گام بعد
    X = np.array(X)  # (N, seq_len, F)
    Y = np.array(Y)  # (N, n_out)

    sz = math.ceil(X.shape[0]*perc/100)
    xtrain, ytrain = X[:sz], Y[:sz]
    xtest,  ytest  = X[sz-1:], Y[sz-1:]
    return xtrain, ytrain, xtest, ytest

#%% داده
data = pd.read_csv('/Users/grayman/Documents/PhD/Data/EURUSD-NonZiro.csv',
                   sep=',', index_col='Date', parse_dates=True)

new_data = data.iloc[1516:,[0,1,2,3]].to_numpy()  # OHLC
percentage = 60
SEQ_LEN = 32          # ✨ طول توالی TCN (در صورت امکان 64 هم تست کن)
N_OUT   = 4           # FLF: چهار خروجی (OHLC)

xtrain, ytrain, xtest, ytest = tagData(new_data, percentage, seq_len=SEQ_LEN, n_out=N_OUT)
print('training samples: ', xtrain.shape)
print('testing samples: ', xtest.shape)

#%%
activations=['tanh','relu','sigmoid']  # حلقه را نگه می‌داریم؛ اثر را روی Dense میانی می‌گذاریم
history_dictionary = {}
# توصیه: clipnorm برای پایداری در TCN
opt = Nadam(lr=1e-5, beta_1=0.09, beta_2=0.0999, epsilon=None, schedule_decay=0.0004, clipnorm=1.0)
predictions = {}

#%%
@tf.function
def FLF(yTrue, yPred):
    lam = 0.1
    v   = Lambda(lambda x: x*0.9)( (yTrue-yPred) )
    vn  = Lambda(lambda x: x*lam)(K.abs((yTrue[:,1]+yTrue[:,2])/2 - (yPred[:,1]+yPred[:,2])/2))
    vn1 = Lambda(lambda x: x*lam)(K.abs((yTrue[:,0]+yTrue[:,3])/2 - (yPred[:,0]+yPred[:,3])/2))
    vx  = K.square((v[:,0]-vn1))
    vy  = K.square((v[:,1]-vn))
    vz  = K.square((v[:,2]-vn))
    v4  = K.square((v[:,3]-vn1))
    vm  = K.concatenate([vx, vy, vz, v4])
    return K.mean(vm)

#%% TCN params
DILATIONS = [1, 2, 4, 8]
FILTERS   = 64
KERNEL    = 3
DROPOUT   = 0.05

units = 200      # بی‌اثر در TCN ولی برای سازگاری نگه‌داشته شده
epochs = 150
verbose = 0

for i, act in enumerate(activations):
    start = time.time()

    inp = Input(shape=(xtrain.shape[1], xtrain.shape[2]))  # (seq_len, F)
    x = inp
    for d in DILATIONS:
        res = x
        x = Conv1D(FILTERS, KERNEL, padding='causal', dilation_rate=d, activation='relu')(x)
        x = Dropout(DROPOUT)(x)
        x = Conv1D(FILTERS, KERNEL, padding='causal', dilation_rate=d)(x)
        # تطبیق کانال برای اتصال میان‌بُر
        if res.shape[-1] != x.shape[-1]:
            res = Conv1D(FILTERS, 1, padding='same')(res)
        x = Add()([res, x])
        x = Activation('relu')(x)
    x = GlobalAveragePooling1D()(x)
    # برای اینکه حلقه activations بی‌اثر نباشد، یک Dense میانی با act اضافه می‌کنیم
    x = Dense(64, activation=act)(x)
    out = Dense(N_OUT)(x)
    cand = Model(inp, out)

    cand.compile(loss=FLF, optimizer=opt)
    cand_history = cand.fit(
        xtrain, ytrain,
        epochs=epochs, batch_size=72,
        validation_data=(xtest, ytest),
        verbose=verbose, shuffle=False
    )
    history_dictionary[act] = (cand_history, cand)
    print("done training model with activation", act, "  ", i+1,"/", len(activations), "completed.")
    end = time.time()
    print("time of execution = ", end-start, "seconds")
    model.save("TCN_FLF_model.h5")

#%%
def evaluate(xtest, name="Open", filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High": 1, "Low": 2, "Close": 3}
    groups = {"Open": [], "High": [], "Low": [], "Close": []}
    with open(filename, "w") as f:
        for label, pair in history_dictionary.items():
            model = pair[1]
            prediCand = model.predict(xtest, verbose=0)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:, id_]
                act = ytest[:, id_]
                mean_sq_err = mase(act, pred, ytrain[:, id_])
                output = f"{label},{name}(MASE),{mean_sq_err}\n"
                print(label, ": ", name, " MASE => ", mean_sq_err)
                f.write(output)
            print(".................................................")
            # اگر دوست داری گروه‌ها را پر کنی:
            for nm, j in mapp.items():
                groups[nm].append(mase(ytest[:, j], predictions[label][:, j], ytrain[:, j]))
    return groups

#%%
dictionary  = evaluate(xtest,"Open","FLF_MASE_result.txt")
print(history_dictionary.items())

#%%
def plot_validation_loss(filename="validation_loss.pdf"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
    plt.title('Candle validation loss(MASE)')
    plt.ylabel('loss'); plt.xlabel('epochs')
    plt.legend(loc='best')
    plt.savefig(filename,format="pdf")
    plt.show()

plot_validation_loss("FLF_MASE_validation_loss.pdf")

def save_pred(path= ""):
    for k, v in predictions.items():
        file_name = path + "./Org_FLF_MASE" + k + ".csv"
        df = pd.DataFrame({'Open': v[:,0], 'High': v[:,1], 'Low': v[:,2], 'Close': v[:,3]})
        df.to_csv(file_name, index=False)
    print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.pdf'):
    barWidth = 0.12
    r1 = np.arange(n); r2 = [x + barWidth for x in r1]
    r3 = [x + barWidth for x in r2]; r4 = [x + barWidth for x in r3]
    plt.figure(figsize=(5, 4))
    if n==2:
        dictionary2={}; groups = ['tanh', 'relu']
        for k, v in dictionary.items(): dictionary2[k] = [v[0], v[2]]
    elif n==3:
        groups = ['tanh', 'sigmoid', 'relu']; dictionary2 = dictionary

    plt.bar(r1, dictionary2['Open'],  width=barWidth, edgecolor='white', label='Open-Price')
    plt.bar(r2, dictionary2['High'],  width=barWidth, edgecolor='white', label='High-Price')
    plt.bar(r3, dictionary2['Low'],   width=barWidth, edgecolor='white', label='Low-Price')
    plt.bar(r4, dictionary2['Close'], width=barWidth, edgecolor='white', label='Close-Price')
    plt.xlabel('activation function', fontweight='bold')
    plt.ylabel('MASE', fontweight='bold')
    plt.xticks([r + barWidth for r in range(n)], groups)
    plt.legend(loc = 'best')
    plt.savefig(filename,format="pdf"); plt.show()

plot_error(dictionary,3,'FLF_MASE_my_error_plot.pdf')

def plot(name="Open", filename="plot.pdf"):
    mapp = {"Open":0,"open":0,"High":1,"high":1,"Low":2,"low":2,"Close":3,"close":3}
    plt.figure(figsize=(8,5))
    id_ = mapp[name]; act = ytest[:,id_]
    label_2 = 'actual '+ name + ' price'
    plt.plot(act[:len(act)-1], label=label_2)
    for label, prediCand in predictions.items():
        pred = prediCand[:, id_]
        label_1 = label+ ': Predicted '+ name + ' price'
        plt.plot(pred[:len(pred)-1], label=label_1)
        plt.xlabel('Time steps'); plt.ylabel('Price')
        plt.title('EUR/USD '+ name +' price'); plt.grid(True); plt.legend(loc='best')
    plt.savefig(filename,format="pdf"); plt.show()

plot("Open","Open_FLF_MASE.pdf")
plot("High","High_FLF_MASE.pdf")
plot("Low","Low_FLF_MASE.pdf")
plot("Close","Close_FLF_MASE.pdf")