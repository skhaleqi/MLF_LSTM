#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  7 15:23:33 2023

@author: grayman
"""

#%%
import numpy as np
import time
import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Lambda

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, GRU, Activation
from tensorflow.keras.layers import Dense, Bidirectional, LSTM
# from keras.layers import CuDNNLSTM
from tensorflow.keras.optimizers import Nadam
import math
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

import random
import numpy
from tensorflow.compat.v1.random import set_random_seed

#%%
random.seed(1)
numpy.random.seed(1)
set_random_seed(2)

def mse(predictions, targets):
        return ((predictions - targets) ** 2).mean()
    
def rmse(actual, predicted):
    actual = np.array(actual)
    predicted = np.array(predicted)
    mse = np.mean((actual - predicted) ** 2)
    rmse_value = np.sqrt(mse)
    return rmse_value

def mae(actual, predicted):
    actual = np.array(actual)
    predicted = np.array(predicted)
    mae_value = np.mean(np.abs(actual - predicted))
    return mae_value

import numpy as np

def r2_score(actual, predicted):
    actual = np.array(actual)
    predicted = np.array(predicted)
    mean_actual = np.mean(actual)
    ss_total = np.sum((actual - mean_actual) ** 2)
    ss_residual = np.sum((actual - predicted) ** 2)
    r2_value = 1 - (ss_residual / ss_total)    
    return r2_value


def mape(actual, predicted):
    epsilon = 1e-6  # جلوگیری از تقسیم بر صفر
    actual = np.array(actual)
    predicted = np.array(predicted)
    mape_value = np.mean(np.abs((actual - predicted) / (actual + epsilon))) * 100
    return mape_value

# محاسبه MASE
def mase(actual, predicted, train_data):
    epsilon = 1e-6  # جلوگیری از تقسیم بر صفر
    actual = np.array(actual)
    predicted = np.array(predicted)
    train_data = np.array(train_data)

    # محاسبه پیش‌بینی Naive
    naive_forecast = np.roll(train_data, 1)[1:]  # شیفت به سمت راست برای پیش‌بینی Naive
    mae_naive = mae(train_data[1:], naive_forecast)
    mae_value = mae(actual, predicted)
    mase_value = mae_value / (mae_naive + epsilon)
    return mase_value

def smape(actual, predicted):
    actual = np.array(actual)
    predicted = np.array(predicted)
    return 100 * np.mean(2 * np.abs(actual - predicted) / (np.abs(actual) + np.abs(predicted)))

def readDataset(filename):
    text_file = open(filename, 'r')
    dataset = []   
    for line in text_file:  
        line = line.split(',')      
        dt = [ float(x) for x in line ]
        dataset.append(dt)    
    text_file.close()
    dataset = np.array(dataset)
    return dataset

def tagData(data, perc):
    sz = math.ceil(data.shape[0]*perc/100)
    dat = np.zeros((data.shape[0], data.shape[1]*2))
    dat[:data.shape[0], :data.shape[1]] =data  #append column for labels
    dat[:data.shape[0]-1, data.shape[1]:] =data[1:,:]  #append column for labels   
    
    xtrain = dat[:sz, :4]
    ytrain = dat[:sz, 4:]
    
    xtest = dat[sz-1:, :4]
    ytest = dat[sz-1:, 4:]
    
    xtrain = xtrain.reshape((xtrain.shape[0], 1, xtrain.shape[1]))
    xtest = xtest.reshape((xtest.shape[0], 1, xtest.shape[1]))
    
    return xtrain, ytrain, xtest, ytest



#%%

data = pd.read_csv('/Users/grayman/Documents/PhD/Data/EURUSD-NonZiro.csv',sep=',',index_col='Date',parse_dates=True)
#print(data.head())

new_data = data.iloc[1516:,[0,1,2,3]]
new_data = np.array(new_data)
#print(new_data.head())

#print(data.shape);


percentage = 60

xtrain, ytrain,xtest,ytest = tagData(new_data,percentage)
print('training samples: ', xtrain.shape)
print('testing samples: ', xtest.shape)

#%%

activations=['tanh','relu','sigmoid']
history_dictionary = {}
opt = Nadam(lr=0.00001, beta_1=0.09, beta_2=0.0999, epsilon=None, schedule_decay=0.0004)
predictions = {}

#%%
@tf.function
def FLF(yTrue, yPred):
     lam = 0.1
     v   = Lambda(lambda x: x*0.9)((yTrue-yPred))
     vn  = Lambda(lambda x: x*lam)(K.abs((yTrue[:,1]+yTrue[:,2])/2 - (yPred[:,1]+yPred[:,2])/2))
     vn1 = Lambda(lambda x: x*lam)(K.abs((yTrue[:,0]+yTrue[:,3])/2 - (yPred[:,0]+yPred[:,3])/2))
     vx  = K.square((v[:,0]-vn1))
     vy  = K.square((v[:,1]-vn))
     vz  = K.square((v[:,2]-vn))
     v4  = K.square((v[:,3]-vn1))
     vm  = K.concatenate([vx, vy, vz, v4])
     vmx = K.mean(vm)
     return vmx



#%%

units=200
epochs = 150
verbose=0

for i, act in enumerate(activations):
    start =  time.time()
    cand = Sequential()
    cand.add(Bidirectional(LSTM(units, activation=act), input_shape=(xtrain.shape[1], xtrain.shape[2])))
    cand.add(Dense(4))
    ############################
    cand.compile(loss=FLF, optimizer=opt)#'Nadam'
    cand_history = cand.fit(xtrain, ytrain, epochs=epochs, batch_size=72, validation_data=(xtest, ytest), verbose=verbose, shuffle=False)
    history_dictionary[act] = (cand_history, cand)
    print("done training model with activation", act, "  ", i+1,"/", len(activations), "completed.")
    end =  time.time()
    print("time of execution = ", end-start, "seconds")

   
#%% MASE

def evaluate(xtest, name="Open", filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High": 1, "Low": 2, "Close": 3}
    groups = {"Open": [], "High": [], "Low": [], "Close": []}
    with open(filename, "w") as f:
        for label, pair in history_dictionary.items():
            model = pair[1]
            prediCand = model.predict(xtest)
            df_save = pd.DataFrame({
                "y_true_Open": ytest[:, 0],
                "y_pred_Open": prediCand[:, 0],
                "y_true_High": ytest[:, 1],
                "y_pred_High": prediCand[:, 1],
                "y_true_Low": ytest[:, 2],
                "y_pred_Low": prediCand[:, 2],
                "y_true_Close": ytest[:, 3],
                "y_pred_Close": prediCand[:, 3]
            })
            df_save.to_csv(f"Results_BiLSTM_FLF_{label}.csv", index=False)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:, id_]
                act = ytest[:, id_]
                mean_sq_err = mase(act, pred, ytrain[:, id_])  # اضافه شدن ytrain به عنوان train_data
                output = f"{label},{name}(MASE),{mean_sq_err}\n"
                print(label, ": ", name, " MASE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups


dictionary  = evaluate(xtest,"Open","BiLSTM_FLF_MASE_result.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.pdf"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('BiLSTM Candle validation loss(MASE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename,format="pdf")    
    plt.show()

plot_validation_loss("BiLSTM_FLF_MASE_validation_loss.pdf")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./BiLSTM_Org_FLF_MASE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.pdf'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('BiLSTM FLF MASE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename,format="pdf")
        plt.show()
        
plot_error(dictionary,3,'BiLSTM_FLF_MASE_my_error_plot.pdf')


def plot( name="Open", filename="plot.pdf"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename,format="pdf")
        plt.show()

plot("Open","BiLSTM_Open_FLF_MASE.pdf")
plot("High","BiLSTM_High_FLF_MASE.pdf")
plot("Low","BiLSTM_Low_FLF_MASE.pdf")
plot("Close","BiLSTM_Close_FLF_MASE.pdf")

#%% MSE
def evaluate(xtest, name="Open", filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High": 1, "Low": 2, "Close": 3}
    groups = {"Open": [], "High": [], "Low": [], "Close": []}
    with open(filename, "w") as f:
        for label, pair in history_dictionary.items():
            model = pair[1]
            prediCand = model.predict(xtest)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:, id_]
                act = ytest[:, id_]
                mean_sq_err = mse(act, pred)  # اضافه شدن ytrain به عنوان train_data
                output = f"{label},{name}(MSE),{mean_sq_err}\n"
                print(label, ": ", name, " MSE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

dictionary  = evaluate(xtest,"Open","BiLSTM_FLF_MSE_result.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.pdf"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('BiLSTM Candle validation loss(MSE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename,format="pdf")    
    plt.show()

plot_validation_loss("BiLSTM_FLF_MSE_validation_loss.pdf")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./BiLSTM_Org_FLF_MSE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.pdf'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('BiLSTM FLF MSE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename,format="pdf")
        plt.show()
        
plot_error(dictionary,3,'BiLSTM_FLF_MSE_my_error_plot.pdf')


def plot( name="Open", filename="plot.pdf"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename,format="pdf")
        plt.show()

plot("Open","BiLSTM_Open_FLF_MSE.pdf")
plot("High","BiLSTM_High_FLF_MSE.pdf")
plot("Low","BiLSTM_Low_FLF_MSE.pdf")
plot("Close","BiLSTM_Close_FLF_MSE.pdf")

#%% RMSE
def evaluate(xtest, name="Open", filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High": 1, "Low": 2, "Close": 3}
    groups = {"Open": [], "High": [], "Low": [], "Close": []}
    with open(filename, "w") as f:
        for label, pair in history_dictionary.items():
            model = pair[1]
            prediCand = model.predict(xtest)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:, id_]
                act = ytest[:, id_]
                mean_sq_err = rmse(act, pred)  # اضافه شدن ytrain به عنوان train_data
                output = f"{label},{name}(RMSE),{mean_sq_err}\n"
                print(label, ": ", name, " RMSE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

dictionary  = evaluate(xtest,"Open","BiLSTM_FLF_RMSE_result.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.pdf"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('BiLSTM Candle validation loss(RMSE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename,format="pdf")    
    plt.show()

plot_validation_loss("BiLSTM_FLF_RMSE_validation_loss.pdf")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./BiLSTM_Org_FLF_RMSE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.pdf'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('BiLSTM FLF RMSE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename,format="pdf")
        plt.show()
        
plot_error(dictionary,3,'BiLSTM_FLF_RMSE_my_error_plot.pdf')


def plot( name="Open", filename="plot.pdf"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename,format="pdf")
        plt.show()

plot("Open","BiLSTM_Open_FLF_RMSE.pdf")
plot("High","BiLSTM_High_FLF_RMSE.pdf")
plot("Low","BiLSTM_Low_FLF_RMSE.pdf")
plot("Close","BiLSTM_Close_FLF_RMSE.pdf")

#%% MAE
def evaluate(xtest, name="Open", filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High": 1, "Low": 2, "Close": 3}
    groups = {"Open": [], "High": [], "Low": [], "Close": []}
    with open(filename, "w") as f:
        for label, pair in history_dictionary.items():
            model = pair[1]
            prediCand = model.predict(xtest)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:, id_]
                act = ytest[:, id_]
                mean_sq_err = mae(act, pred)  # اضافه شدن ytrain به عنوان train_data
                output = f"{label},{name}(MAE),{mean_sq_err}\n"
                print(label, ": ", name, " MAE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

dictionary  = evaluate(xtest,"Open","BiLSTM_FLF_MAE_result.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.pdf"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('BiLSTM Candle validation loss(MAE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename,format="pdf")    
    plt.show()

plot_validation_loss("BiLSTM_FLF_MAE_validation_loss.pdf")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./BiLSTM_Org_FLF_MAE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.pdf'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('BiLSTM FLF MAE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename,format="pdf")
        plt.show()
        
plot_error(dictionary,3,'BiLSTM_FLF_MAE_my_error_plot.pdf')


def plot( name="Open", filename="plot.pdf"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename,format="pdf")
        plt.show()

plot("Open","BiLSTM_Open_FLF_MAE.pdf")
plot("High","BiLSTM_High_FLF_MAE.pdf")
plot("Low","BiLSTM_Low_FLF_MAE.pdf")
plot("Close","BiLSTM_Close_FLF_MAE.pdf")


#%% MAPE
def evaluate(xtest, name="Open", filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High": 1, "Low": 2, "Close": 3}
    groups = {"Open": [], "High": [], "Low": [], "Close": []}
    with open(filename, "w") as f:
        for label, pair in history_dictionary.items():
            model = pair[1]
            prediCand = model.predict(xtest)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:, id_]
                act = ytest[:, id_]
                mean_sq_err = mape(act, pred)  # اضافه شدن ytrain به عنوان train_data
                output = f"{label},{name}(MAPE),{mean_sq_err}\n"
                print(label, ": ", name, " MAPE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

dictionary  = evaluate(xtest,"Open","BiLSTM_FLF_MAPE_result.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.pdf"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('BiLSTM Candle validation loss(MAPE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename,format="pdf")    
    plt.show()

plot_validation_loss("BiLSTM_FLF_MAPE_validation_loss.pdf")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./BiLSTM_Org_FLF_MAPE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.pdf'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('BiLSTM FLF MAPE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename,format="pdf")
        plt.show()
        
plot_error(dictionary,3,'BiLSTM_FLF_MAPE_my_error_plot.pdf')


def plot( name="Open", filename="plot.pdf"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename,format="pdf")
        plt.show()

plot("Open","BiLSTM_Open_FLF_MAPE.pdf")
plot("High","BiLSTM_High_FLF_MAPE.pdf")
plot("Low","BiLSTM_Low_FLF_MAPE.pdf")
plot("Close","BiLSTM_Close_FLF_MAPE.pdf")

#%% SMAPE
def evaluate(xtest, name="Open", filename="evaluation_results.txt"):
    print('predicting candles and evaluating models...')
    mapp = {"Open": 0, "High": 1, "Low": 2, "Close": 3}
    groups = {"Open": [], "High": [], "Low": [], "Close": []}
    with open(filename, "w") as f:
        for label, pair in history_dictionary.items():
            model = pair[1]
            prediCand = model.predict(xtest)
            predictions[label] = prediCand
            for name, id_ in mapp.items():
                pred = prediCand[:, id_]
                act = ytest[:, id_]
                mean_sq_err = smape(act, pred)  # اضافه شدن ytrain به عنوان train_data
                output = f"{label},{name}(sMAPE),{mean_sq_err}\n"
                print(label, ": ", name, " sMAPE => ", mean_sq_err)
                f.write(output)
                groups[name].append(mean_sq_err)
            print(".................................................")
    return groups

dictionary  = evaluate(xtest,"Open","BiLSTM_FLF_sMAPE_result.txt")
print(history_dictionary.items())

def plot_validation_loss(filename="validation_loss.pdf"):
    plt.figure(figsize=(8,5))
    for label, pair in history_dictionary.items():
        cand_history = pair[0]
        plt.plot(cand_history.history['val_loss'], label=label)
        plt.title('BiLSTM Candle validation loss(sMAPE)')
        plt.ylabel('loss')
        plt.xlabel('epochs')
        plt.legend(loc='best')
    plt.savefig(filename,format="pdf")    
    plt.show()

plot_validation_loss("BiLSTM_FLF_sMAPE_validation_loss.pdf")

def save_pred(path= ""):
        for k, v in predictions.items():
            file_name = path + "./BiLSTM_Org_FLF_sMAPE" + k + ".csv"
            df = pd.DataFrame()
            df['Open'] = v[:,0]
            df['High'] = v[:,1]
            df['Low'] =  v[:,2]
            df['Close'] = v[:,3]
            df.to_csv(file_name)
        print("done writting all..")

def plot_error(dictionary, n, filename='error_plot.pdf'):
        # set width of bar
        barWidth = 0.12
        # Set position of bar on X axis
        r1 = np.arange(n)
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]
        r4 = [x + barWidth for x in r3]
        plt.figure(figsize=(5, 4))
        # Make the plot
        if(n==2):
            dictionary2={}
            groups = ['tanh', 'relu']
            for k, v in dictionary.items():
                dictionary2[k] = [v[0], v[2]]
        elif(n==3):
            groups = ['tanh', 'sigmoid', 'relu']
            dictionary2 = dictionary

        plt.bar(r1, dictionary2['Open'],  color='#7f6d5f', width=barWidth, edgecolor='white', label='Open-Price')
        plt.bar(r2, dictionary2['High'],  color='#fc9803', width=barWidth, edgecolor='white', label='High-Price')
        plt.bar(r3, dictionary2['Low'],   color='#2d7f5e', width=barWidth, edgecolor='white', label='Low-Price')
        plt.bar(r4, dictionary2['Close'], color='#2003fc', width=barWidth, edgecolor='white', label='Close-Price')

        # Add xticks on the middle of the group bars
        plt.xlabel('activation function', fontweight='bold')
        plt.ylabel('BiLSTM FLF sMAPE', fontweight='bold')
        plt.xticks([r + barWidth for r in range(n)], groups)
        # Create legend & Show graphic
        plt.legend(loc= "best")
        plt.savefig(filename,format="pdf")
        plt.show()
        
plot_error(dictionary,3,'BiLSTM_FLF_sMAPE_my_error_plot.pdf')


def plot( name="Open", filename="plot.pdf"):
        mapp = {"Open": 0, "open":0,  "High":1, "high":1 ,   "Low":2, "low":2 , "Close":3, "close":3 }
        plt.figure(figsize=(8,5))
        id_ = mapp[name]
        act = ytest[:,id_]
        label_2 = 'actual '+ name + ' price'
        plt.plot(act[:len(act)-1],     label = label_2)
        for label, prediCand in predictions.items():
            pred = prediCand[:, id_]
            label_1 = label+ ': Predicted '+ name + ' price'
            plt.plot(pred[:len(pred)-1],   label = label_1);
            plt.xlabel('Time steps')
            plt.ylabel('Price')
            plt.title('EUR/USD '+ name +' price')
            plt.grid(True)
            plt.legend(loc = 'best')
        plt.savefig(filename,format="pdf")
        plt.show()

plot("Open","BiLSTM_Open_FLF_sMAPE.pdf")
plot("High","BiLSTM_High_FLF_sMAPE.pdf")
plot("Low","BiLSTM_Low_FLF_sMAPE.pdf")
plot("Close","BiLSTM_Close_FLF_sMAPE.pdf")